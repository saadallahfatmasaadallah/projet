package soa.metier;

import soa.entities.Categorie;

public interface CategorieMetierInterface
{
    void ajouterCategorie(Categorie c);

}
